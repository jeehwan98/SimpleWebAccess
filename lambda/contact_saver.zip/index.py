import boto3
import json
import os
import uuid
from datetime import datetime, timezone

s3 = boto3.client("s3")
S3_BUCKET = os.environ["S3_BUCKET"]


def handler(event, context):
    for record in event["Records"]:
        body = json.loads(record["body"])

        key = f"contacts/{datetime.now(timezone.utc).strftime('%Y/%m/%d')}/{uuid.uuid4()}.json"

        s3.put_object(
            Bucket=S3_BUCKET,
            Key=key,
            Body=json.dumps(body),
            ContentType="application/json",
        )

    return {"statusCode": 200}
